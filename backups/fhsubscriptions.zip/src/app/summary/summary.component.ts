import { Component, Input, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { MenuItemSummaryInfo } from '../models/menu-item-summary-info';
import { SubscriptionRequestSummary } from '../models/subscription-request-summary';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {

  @Input() public menuItemSummaries: MenuItemSummaryInfo[];

  public deliveryFee: number = 0;
  public packagingCharges: number = 0;
  public deliveryPlan: string = "Weekly";
  public deliveryDate: string;
  public deliveryTime: string;
  public isTodayAvailable: boolean = true;

  constructor(private router: Router) {
    const currentTime = new Date();
    const currentHours = currentTime.getHours();

    if (currentHours >= 12) {
      this.isTodayAvailable = false;
    }
  }

  ngOnInit(): void {
  }

  navigate($event: any) {
    const subscriptionRequestSummary: SubscriptionRequestSummary = {
      menuItemSummaries: this.menuItemSummaries,
      deliveryFee: this.deliveryFee,
      packagingCharges: this.packagingCharges,
      deliveryPlan: this.deliveryPlan,
      deliveryDate: this.deliveryDate,
      deliveryTime: this.deliveryTime
    };

    const navigationExtraDetails: NavigationExtras = {
      state: subscriptionRequestSummary
    };

    this.router.navigate(["businessinfo"], navigationExtraDetails);
  }
}
