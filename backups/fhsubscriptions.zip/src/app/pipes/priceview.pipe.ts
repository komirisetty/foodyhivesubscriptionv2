import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'priceview'
})
export class PriceviewPipe implements PipeTransform {

  transform(value: number, ...args: unknown[]): string {
    let processedPriceString = "";

    if (value <= 0 || value === undefined || value === null) {
      processedPriceString = "TBD";
    }
    else {
      processedPriceString = `₹ ${value.toString()}`;
    }

    return processedPriceString;
  }

}
