import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SubscriberInfo } from '../models/subscriber-info';
import { SubscriptionRequestSummary } from '../models/subscription-request-summary';
import { SubscriptionRequestMapService } from '../services/subscription-request-map-service';
import { SubscriptionRequestsService } from '../services/subscriptionrequests.service';

const HARD_CODED_TOTAL = 938;

@Component({
  selector: 'app-summaryview',
  templateUrl: './summaryview.component.html',
  styleUrls: ['./summaryview.component.css']
})
export class SummaryviewComponent implements OnInit {

  @Input() public subscriptionRequestSummary: SubscriptionRequestSummary;
  @Input() public subscriberInfo: SubscriberInfo;
  public errorMessage: string = '';

  public totalAmount: number = HARD_CODED_TOTAL;

  constructor(private router: Router,
    private subscriptionRequestMapService: SubscriptionRequestMapService,
    private subscriptionrequestsService: SubscriptionRequestsService) { }

  ngOnInit(): void {
  }

  confirmOrder($event: any) {
    const subscriptionRequest = this.subscriptionRequestMapService.map(this.subscriptionRequestSummary, this.subscriberInfo);

    this
      .subscriptionrequestsService
      .submitSubscriptionRequest(subscriptionRequest)
      .subscribe(response => {
        if (response.isSuccess) {
          this.router.navigate(["confirmation"]);
        } else {
          this.errorMessage = response.errorMessage;
        }
      });
  }
}
