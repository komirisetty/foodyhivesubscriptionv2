import { MenuItem } from './menuitem';

describe('Menuitem', () => {
  it('should create an instance', () => {
    expect(new MenuItem()).toBeTruthy();
  });
});
