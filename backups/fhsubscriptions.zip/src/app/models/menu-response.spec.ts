import { MenuResponse } from './menu-response';

describe('MenuItemResponse', () => {
  it('should create an instance', () => {
    expect(new MenuResponse()).toBeTruthy();
  });
});
