export class SubscriptionRequestResponse {
    isSuccess: boolean;
    successMessage: string;
    errorMessage: string;
    data: string;
}
