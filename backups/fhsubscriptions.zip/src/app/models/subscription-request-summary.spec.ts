import { SubscriptionRequestSummary } from './subscription-request-summary';

describe('SubscriptionRequestSummary', () => {
  it('should create an instance', () => {
    expect(new SubscriptionRequestSummary()).toBeTruthy();
  });
});
