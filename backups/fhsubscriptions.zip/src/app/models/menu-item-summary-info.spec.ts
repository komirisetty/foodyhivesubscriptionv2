import { MenuItemSummaryInfo } from './menu-item-summary-info';

describe('MenuItemSummaryInfo', () => {
  it('should create an instance', () => {
    expect(new MenuItemSummaryInfo()).toBeTruthy();
  });
});
