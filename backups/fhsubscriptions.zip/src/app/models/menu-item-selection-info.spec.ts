import { MenuItemSelectionInfo } from './menu-item-selection-info';

describe('MenuItemSelectionInfo', () => {
  it('should create an instance', () => {
    expect(new MenuItemSelectionInfo()).toBeTruthy();
  });
});
