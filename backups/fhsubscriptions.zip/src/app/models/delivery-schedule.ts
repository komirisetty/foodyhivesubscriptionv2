export interface DeliverySchedule {
    date: Date;
    timeRange: string;
    pointOfContact: string;
}
