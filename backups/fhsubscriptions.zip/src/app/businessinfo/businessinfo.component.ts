import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItemSummaryInfo } from '../models/menu-item-summary-info';
import { SubscriberInfo } from '../models/subscriber-info';
import { SubscriptionRequestSummary } from '../models/subscription-request-summary';

@Component({
  selector: 'app-businessinfo',
  templateUrl: './businessinfo.component.html',
  styleUrls: ['./businessinfo.component.css']
})
export class BusinessinfoComponent implements OnInit {

  public subscriptionRequestSummary: SubscriptionRequestSummary;
  public subscriberInfo: SubscriberInfo;

  constructor(private router: Router) {
    const navigation = this.router.getCurrentNavigation();

    this.subscriptionRequestSummary = navigation.extras.state as SubscriptionRequestSummary;
    this.subscriberInfo = {
      companyName: "",
      fullName: "",
      addressLine1: "",
      addressLine2: "",
      city: "",
      state: "",
      zipCode: "",
      country: "",
      emailAddress: "",
      phoneNumber: ""
    };
  }

  ngOnInit(): void {
  }

}
