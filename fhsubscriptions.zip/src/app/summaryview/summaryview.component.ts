import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SubscriberInfo } from '../models/subscriber-info';
import { SubscriptionRequestSummary } from '../models/subscription-request-summary';
import { SubscriptionRequestMapService } from '../services/subscription-request-map-service';
import { SubscriptionRequestsService } from '../services/subscriptionrequests.service';

const HARD_CODED_TOTAL = 938;

@Component({
  selector: 'app-summaryview',
  templateUrl: './summaryview.component.html',
  styleUrls: ['./summaryview.component.css']
})
export class SummaryviewComponent implements OnInit {

  @Input() public subscriptionRequestSummary: SubscriptionRequestSummary;
  @Input() public subscriberInfo: SubscriberInfo;
  @Input() public validationerror: any;
  public errorMessage: string = '';
  public aftervalidationerror: string = '';

  public totalAmount: number = HARD_CODED_TOTAL;

  constructor(private router: Router,
    private subscriptionRequestMapService: SubscriptionRequestMapService,
    private subscriptionrequestsService: SubscriptionRequestsService) {

  }

  ngOnInit(): void {


  }
  testforvalidation() { //empty field validation
    for (var property in this.subscriberInfo) {
      if (this.subscriberInfo[property] == "") {
        this.validationerror[property] = "* please fill out this field";
        this.aftervalidationerror = "error";
      } else { this.aftervalidationerror = ""; this.validationerror[property] = ""; }
    }
  }
  //validation for zipcode
  validatezip() {

    var regexzip = /^\d{6}$/;// phone validation
    if (this.subscriberInfo.zipCode == "") {
      this.validationerror.zipCode = "* please fill out this field";
      this.aftervalidationerror = "error";
    }
    else if (!regexzip.test(this.subscriberInfo.zipCode)) {
      this.validationerror.zipCode = "*Invalid zipcode";
      this.aftervalidationerror = "error";
    }
    else {
      this.aftervalidationerror = ""; this.validationerror.zipCode = "";
    }
  }
  //validation for Email address
  validateemail() {
    var regexemail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (this.subscriberInfo.emailAddress == "") {
      this.validationerror.emailAddress = "* please fill out this field";
      this.aftervalidationerror = "error";
    }
    else if (!regexemail.test(this.subscriberInfo.emailAddress)) {
      this.validationerror.emailAddress = "* ivalid email address";
      this.aftervalidationerror = "error";
    }
    else {
      this.aftervalidationerror = ""; this.validationerror.emailAddress = "";
    }
  }
  //validation for phone number
  validatephone() {
    var regexphone = /^\d{10}$/;// phone validation
    if (this.subscriberInfo.phoneNumber == "") {
      this.validationerror.phoneNumber = "* please fill out this field";
      this.aftervalidationerror = "error";
    }
    else if (!regexphone.test(this.subscriberInfo.phoneNumber)) {
      this.validationerror.phoneNumber = "* Invalid phone number";
      this.aftervalidationerror = "error";
    }
    else {
      this.aftervalidationerror = ""; this.validationerror.phoneNumber = "";
    }
  }
  confirmOrder($event: any) {
    this.testforvalidation();
    this.validatephone();
    this.validatezip();
    this.validateemail();

    //redirection for success subscription
    if (this.aftervalidationerror === "") {
      const subscriptionRequest = this.subscriptionRequestMapService.map(this.subscriptionRequestSummary, this.subscriberInfo);

      this
        .subscriptionrequestsService
        .submitSubscriptionRequest(subscriptionRequest)
        .subscribe(response => {
          if (response.isSuccess) {
            this.router.navigate(["confirmation"]);
          } else {
            this.errorMessage = response.errorMessage;
          }
        });
    }

  }
}
