import { PriceviewPipe } from './priceview.pipe';

describe('PriceviewPipe', () => {
  it('create an instance', () => {
    const pipe = new PriceviewPipe();
    expect(pipe).toBeTruthy();
  });
});
