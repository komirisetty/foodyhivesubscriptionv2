import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hero-main',
  templateUrl: './hero-main.component.html',
  styleUrls: ['./hero-main.component.css']
})
export class HeroMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
