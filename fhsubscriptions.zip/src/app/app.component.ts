import { Component, OnInit } from '@angular/core';
import { Menu } from './models/menu';
import { MenuCategoryInfo } from './models/menu-category-info';
import { MenuResponse } from './models/menu-response';
import { MenuService } from './services/menu.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'fhsubscriptions';
  public menuCategories: MenuCategoryInfo[] = [];

  constructor(private menuService: MenuService) {
  }

  ngOnInit() {
    this
      .menuService
      .getMenuItems()
      .subscribe(response => {
        if (response.isSuccess) {
          const menus: Menu[] = response.data;

          menus.forEach(menu => {
            const menuCategoryInfo: MenuCategoryInfo = {
              categoryName: menu.categoryTitle,
              noOfDishes: menu.menuDetails.length
            };

            this.menuCategories.push(menuCategoryInfo);
          })
        } else {
          throw new Error(response.errorMessage);
        }
      });
  }

  onActivate(e, scrollContainer) {
    scrollContainer.scrollTop = 0;
  }
}
