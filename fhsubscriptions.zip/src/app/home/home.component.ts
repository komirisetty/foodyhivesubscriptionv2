import { Component, OnInit } from '@angular/core';
import { Menu } from '../models/menu';
import { MenuItemSelectionInfo } from '../models/menu-item-selection-info';
import { MenuItemSummaryInfo } from '../models/menu-item-summary-info';
import { MenuService } from '../services/menu.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public menu: Menu[] = [];
  public menuItemSelections: Map<string, MenuItemSummaryInfo>;
  public menuSelections: MenuItemSummaryInfo[];

  constructor(private menuService: MenuService) {
    this.menuItemSelections = new Map<string, MenuItemSummaryInfo>();
    this.menuSelections = [];
  }

  ngOnInit(): void {
    this
      .menuService
      .getMenuItems()
      .subscribe(menuResponse => {
        if (menuResponse.isSuccess) {
          this.menu = menuResponse.data;

          this.menu.forEach(menuInfo => {
            const categoryId = menuInfo.id;

            menuInfo.menuDetails.forEach(menuItemInfo => {
              const uniqueDishId = `${categoryId}${menuItemInfo.dishId}`;

              menuItemInfo.uniqueDishId = uniqueDishId;
            });
          });
        }
        else {
          throw new Error(menuResponse.errorMessage);
        }
      });
  }

  handleMenuItemChanged(menuItemSelectionInfo: MenuItemSelectionInfo) {
    const dishName = menuItemSelectionInfo.menuItem.dishName
    const totalAmount = menuItemSelectionInfo.quantity * menuItemSelectionInfo.menuItem.saleAmount;

    const menuItemSummaryInfo: MenuItemSummaryInfo = {
      dishName,
      quantity: menuItemSelectionInfo.quantity,
      saleAmount: menuItemSelectionInfo.menuItem.saleAmount,
      totalAmount
    };

    if (menuItemSelectionInfo.quantity <= 0) {
      this.menuItemSelections.delete(dishName);
    }
    else {
      this.menuItemSelections.set(dishName, menuItemSummaryInfo);
    }

    this.menuSelections = [...this.menuItemSelections.values()];
  }
}
