import { SubscriptionRequest } from './subscription-request';

describe('SubscriptionRequest', () => {
  it('should create an instance', () => {
    expect(new SubscriptionRequest()).toBeTruthy();
  });
});
