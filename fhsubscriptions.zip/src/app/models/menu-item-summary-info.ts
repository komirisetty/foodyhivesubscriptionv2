export class MenuItemSummaryInfo {
    public dishName: string;
    public quantity: number;
    public saleAmount: number;
    public totalAmount: number;
    }
