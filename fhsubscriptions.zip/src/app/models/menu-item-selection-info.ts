import { MenuItem } from "./menuitem";

export class MenuItemSelectionInfo {
    public menuItem: MenuItem;
    public quantity: number;
}
