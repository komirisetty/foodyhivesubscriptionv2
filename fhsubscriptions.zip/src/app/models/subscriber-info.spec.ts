import { SubscriberInfo } from './subscriber-info';

describe('SubscriberInfo', () => {
  it('should create an instance', () => {
    expect(new SubscriberInfo()).toBeTruthy();
  });
});
