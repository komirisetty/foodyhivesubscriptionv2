export class MenuCategoryInfo {
    public categoryName: string;
    public noOfDishes: number;
}
